//
//  Article.swift
//  NewsReader1
//
//  Created by cse on 11/6/18.
//  Copyright © 2018 mac. All rights reserved.
//

import UIKit

class Article: NSObject {
    var headline:String?
    var desc :String?
    var author:String?
    var url:String?
    var imageUrl:String?
    
}
